"use client";

import { useEffect, useRef } from "react";
import "./shapeGrid.css";

interface ShapeGridProps {
    direction?: "up" | "down" | "left" | "right" | "diagonal";
    speed?: number;
    borderColor?: string;
    squareSize?: number;
    hoverFillColor?: string;
    shape?: "square" | "hexagon" | "circle" | "triangle";
    hoverTrailAmount?: number;
    className?: string;
}

interface Cell {
    x: number;
    y: number;
}

const ShapeGrid: React.FC<ShapeGridProps> = ({
    direction = "right",
    speed = 1,
    borderColor = "#999",
    squareSize = 40,
    hoverFillColor = "#222",
    shape = "square",
    hoverTrailAmount = 0,
    className = "",
}) => {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const requestRef = useRef<number>(0);

    const numSquaresX = useRef<number>(0);
    const numSquaresY = useRef<number>(0);

    const gridOffset = useRef({ x: 0, y: 0 });

    const hoveredSquare = useRef<Cell | null>(null);

    const trailCells = useRef<Cell[]>([]);

    const cellOpacities = useRef<Map<string, number>>(new Map());

    useEffect(() => {
        const canvas = canvasRef.current;

        if (!canvas) return;

        const ctx = canvas.getContext("2d");

        if (!ctx) return;

        const isHex = shape === "hexagon";
        const isTri = shape === "triangle";

        const hexHoriz = squareSize * 1.5;
        const hexVert = squareSize * Math.sqrt(3);

        const resizeCanvas = () => {
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;

            numSquaresX.current = Math.ceil(canvas.width / squareSize) + 1;
            numSquaresY.current = Math.ceil(canvas.height / squareSize) + 1;
        };

        resizeCanvas();

        window.addEventListener("resize", resizeCanvas);

        const drawHex = (cx: number, cy: number, size: number) => {
            ctx.beginPath();

            for (let i = 0; i < 6; i++) {
                const angle = (Math.PI / 3) * i;

                const vx = cx + size * Math.cos(angle);
                const vy = cy + size * Math.sin(angle);

                if (i === 0) ctx.moveTo(vx, vy);
                else ctx.lineTo(vx, vy);
            }

            ctx.closePath();
        };

        const drawCircle = (cx: number, cy: number, size: number) => {
            ctx.beginPath();
            ctx.arc(cx, cy, size / 2, 0, Math.PI * 2);
            ctx.closePath();
        };

        const drawTriangle = (
            cx: number,
            cy: number,
            size: number,
            flip: boolean
        ) => {
            ctx.beginPath();

            if (flip) {
                ctx.moveTo(cx, cy + size / 2);
                ctx.lineTo(cx + size / 2, cy - size / 2);
                ctx.lineTo(cx - size / 2, cy - size / 2);
            } else {
                ctx.moveTo(cx, cy - size / 2);
                ctx.lineTo(cx + size / 2, cy + size / 2);
                ctx.lineTo(cx - size / 2, cy + size / 2);
            }

            ctx.closePath();
        };

        const updateCellOpacities = () => {
            const targets = new Map<string, number>();

            if (hoveredSquare.current) {
                targets.set(
                    `${hoveredSquare.current.x},${hoveredSquare.current.y}`,
                    1
                );
            }

            if (hoverTrailAmount > 0) {
                trailCells.current.forEach((cell, index) => {
                    const key = `${cell.x},${cell.y}`;

                    if (!targets.has(key)) {
                        targets.set(
                            key,
                            (trailCells.current.length - index) /
                            (trailCells.current.length + 1)
                        );
                    }
                });
            }

            targets.forEach((_, key) => {
                if (!cellOpacities.current.has(key)) {
                    cellOpacities.current.set(key, 0);
                }
            });

            cellOpacities.current.forEach((opacity, key) => {
                const target = targets.get(key) || 0;

                const next = opacity + (target - opacity) * 0.15;

                if (next < 0.005) {
                    cellOpacities.current.delete(key);
                } else {
                    cellOpacities.current.set(key, next);
                }
            });
        };

        const drawGrid = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            if (isHex) {
                const colShift = Math.floor(gridOffset.current.x / hexHoriz);

                const offsetX =
                    ((gridOffset.current.x % hexHoriz) + hexHoriz) % hexHoriz;

                const offsetY =
                    ((gridOffset.current.y % hexVert) + hexVert) % hexVert;

                const cols = Math.ceil(canvas.width / hexHoriz) + 3;
                const rows = Math.ceil(canvas.height / hexVert) + 3;

                for (let col = -2; col < cols; col++) {
                    for (let row = -2; row < rows; row++) {
                        const cx = col * hexHoriz + offsetX;

                        const cy =
                            row * hexVert +
                            ((col + colShift) % 2 !== 0 ? hexVert / 2 : 0) +
                            offsetY;

                        const key = `${col},${row}`;

                        const alpha = cellOpacities.current.get(key);

                        if (alpha) {
                            ctx.globalAlpha = alpha;
                            drawHex(cx, cy, squareSize);
                            ctx.fillStyle = hoverFillColor;
                            ctx.fill();
                            ctx.globalAlpha = 1;
                        }

                        drawHex(cx, cy, squareSize);
                        ctx.strokeStyle = borderColor;
                        ctx.stroke();
                    }
                }
            } else if (shape === "circle") {
                const offsetX =
                    ((gridOffset.current.x % squareSize) + squareSize) % squareSize;

                const offsetY =
                    ((gridOffset.current.y % squareSize) + squareSize) % squareSize;

                const cols = Math.ceil(canvas.width / squareSize) + 3;
                const rows = Math.ceil(canvas.height / squareSize) + 3;

                for (let col = -2; col < cols; col++) {
                    for (let row = -2; row < rows; row++) {
                        const cx =
                            col * squareSize + squareSize / 2 + offsetX;

                        const cy =
                            row * squareSize + squareSize / 2 + offsetY;

                        const key = `${col},${row}`;

                        const alpha = cellOpacities.current.get(key);

                        if (alpha) {
                            ctx.globalAlpha = alpha;
                            drawCircle(cx, cy, squareSize);
                            ctx.fillStyle = hoverFillColor;
                            ctx.fill();
                            ctx.globalAlpha = 1;
                        }

                        drawCircle(cx, cy, squareSize);
                        ctx.strokeStyle = borderColor;
                        ctx.stroke();
                    }
                }
            } else if (isTri) {
                const halfW = squareSize / 2;

                const offsetX =
                    ((gridOffset.current.x % halfW) + halfW) % halfW;

                const offsetY =
                    ((gridOffset.current.y % squareSize) + squareSize) % squareSize;

                const cols = Math.ceil(canvas.width / halfW) + 4;
                const rows = Math.ceil(canvas.height / squareSize) + 4;

                for (let col = -2; col < cols; col++) {
                    for (let row = -2; row < rows; row++) {
                        const cx = col * halfW + offsetX;
                        const cy =
                            row * squareSize + squareSize / 2 + offsetY;

                        const flip = (col + row) % 2 === 0;

                        const key = `${col},${row}`;

                        const alpha = cellOpacities.current.get(key);

                        if (alpha) {
                            ctx.globalAlpha = alpha;
                            drawTriangle(cx, cy, squareSize, flip);
                            ctx.fillStyle = hoverFillColor;
                            ctx.fill();
                            ctx.globalAlpha = 1;
                        }

                        drawTriangle(cx, cy, squareSize, flip);
                        ctx.strokeStyle = borderColor;
                        ctx.stroke();
                    }
                }
            } else {
                const offsetX =
                    ((gridOffset.current.x % squareSize) + squareSize) % squareSize;

                const offsetY =
                    ((gridOffset.current.y % squareSize) + squareSize) % squareSize;

                const cols = Math.ceil(canvas.width / squareSize) + 3;
                const rows = Math.ceil(canvas.height / squareSize) + 3;

                for (let col = -2; col < cols; col++) {
                    for (let row = -2; row < rows; row++) {
                        const sx = col * squareSize + offsetX;
                        const sy = row * squareSize + offsetY;

                        const key = `${col},${row}`;

                        const alpha = cellOpacities.current.get(key);

                        if (alpha) {
                            ctx.globalAlpha = alpha;
                            ctx.fillStyle = hoverFillColor;
                            ctx.fillRect(sx, sy, squareSize, squareSize);
                            ctx.globalAlpha = 1;
                        }

                        ctx.strokeStyle = borderColor;
                        ctx.strokeRect(sx, sy, squareSize, squareSize);
                    }
                }
            }
        };

        const animate = () => {
            const wrapX = isHex ? hexHoriz * 2 : squareSize;
            const wrapY = isHex ? hexVert : squareSize;

            switch (direction) {
                case "right":
                    gridOffset.current.x =
                        (gridOffset.current.x - speed + wrapX) % wrapX;
                    break;

                case "left":
                    gridOffset.current.x =
                        (gridOffset.current.x + speed + wrapX) % wrapX;
                    break;

                case "up":
                    gridOffset.current.y =
                        (gridOffset.current.y + speed + wrapY) % wrapY;
                    break;

                case "down":
                    gridOffset.current.y =
                        (gridOffset.current.y - speed + wrapY) % wrapY;
                    break;

                case "diagonal":
                    gridOffset.current.x =
                        (gridOffset.current.x - speed + wrapX) % wrapX;

                    gridOffset.current.y =
                        (gridOffset.current.y - speed + wrapY) % wrapY;

                    break;
            }

            updateCellOpacities();
            drawGrid();

            requestRef.current = requestAnimationFrame(animate);
        };

        requestRef.current = requestAnimationFrame(animate);

        return () => {
            window.removeEventListener("resize", resizeCanvas);

            if (requestRef.current) {
                cancelAnimationFrame(requestRef.current);
            }
        };
    }, [
        direction,
        speed,
        borderColor,
        squareSize,
        hoverFillColor,
        shape,
        hoverTrailAmount,
    ]);

    return (
        <canvas
            ref={canvasRef}
            className={`shapegrid-canvas ${className}`}
        />
    );
};

export default ShapeGrid;