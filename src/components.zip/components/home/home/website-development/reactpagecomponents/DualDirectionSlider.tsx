"use client";

import React from "react";
import Image from "next/image";

// Replace these imports with your actual image paths
import image1 from "@/assets/images/website-development/React-website/@Corporate-&-Business-Websites.jpg";
import image2 from "@/assets/images/website-development/React-website/@Startups-&-New-Businesses.jpg";
import image3 from "@/assets/images/website-development/React-website/@Real-Estate-Companies.jpg";
import image4 from "@/assets/images/website-development/React-website/@Construction & Infrastructure.jpg";
import image5 from "@/assets/images/website-development/React-website/@Manufacturing-&-Industrial-Businesses.jpg";
import image6 from "@/assets/images/website-development/React-website/@Educational-Institutions.jpg";
import image7 from "@/assets/images/website-development/React-website/@Professional-Services.jpg";
import image8 from "@/assets/images/website-development/React-website/@Healthcare-&-Service-Businesses.jpg";
import image9 from "@/assets/images/website-development/React-website/@E-commerce-&-Online-Businesses.jpg";
import image10 from "@/assets/images/website-development/React-website/@Custom-Web-Applications.jpg";

const rowOneItems = [
    { id: 1, title: "Corporate & Business Websites", image: image1 },
    { id: 2, title: "Startups & New Businesses", image: image2 },
    { id: 3, title: "Real Estate Companies", image: image3 },
    { id: 4, title: "Construction & Infrastructure", image: image4 },
    { id: 5, title: "Manufacturing & Industrial Businesses", image: image5 },
];

const rowTwoItems = [
    { id: 6, title: "Educational Institutions", image: image6 },
    { id: 7, title: "Professional Services", image: image7 },
    { id: 8, title: "Healthcare & Service Businesses", image: image8 },
    { id: 9, title: "E-commerce & Online Businesses", image: image9 },
    { id: 10, title: "Custom Web Applications", image: image10 },
];

const DualDirectionSlider = () => {
  return (
    <section className="dual-slider-section">
      <div className="container-fluid px-0">
        <h2 className="px-about-title mb-2 text-center">
          <span className="text-blue-about">React Website Design</span> for Different Businesses
        </h2>
        <p className="text-figtree text-black mt-2 mb-4 text-center">
          Our React website solutions can be customized for a wide range of industries and business requirements, including
        </p>

        {/* Row 1: Right to Left */}
        <div className="slider-row slider-row-left">
          <div className="slider-track">
            {[...rowOneItems, ...rowOneItems].map((item, index) => (
              <div key={`row1-${item.id}-${index}`} className="slider-card">
                <div className="card-image-wrapper" style={{ position: "relative", width: "100%", height: "100%" }}>
                  <Image
                    src={item.image}
                    alt={item.title}
                    fill
                    sizes="(max-width: 768px) 250px, 320px"
                    priority={index < 3}
                    style={{ objectFit: "cover" }}
                  />
                  <div className="card-overlay" />
                </div>
                <div className="card-content">
                  <h3 className="text-tenor title-h3">{item.title}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Row 2: Left to Right */}
        <div className="slider-row slider-row-right">
          <div className="slider-track">
            {[...rowTwoItems, ...rowTwoItems].map((item, index) => (
              <div key={`row2-${item.id}-${index}`} className="slider-card">
                <div className="card-image-wrapper" style={{ position: "relative", width: "100%", height: "100%" }}>
                  <Image
                    src={item.image}
                    alt={item.title}
                    fill
                    sizes="(max-width: 768px) 250px, 320px"
                    priority={index < 3}
                    style={{ objectFit: "cover" }}
                  />
                  <div className="card-overlay" />
                </div>
                <div className="card-content">
                  <h3 className="text-tenor title-h3">{item.title}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style jsx>{`
        .dual-slider-section {
          padding: 20px 0 40px;
          overflow: hidden;
        }

        .slider-row {
          display: flex;
          width: 100%;
          overflow: hidden;
          margin-bottom: 24px;
          position: relative;
        }

        .slider-row:last-child {
          margin-bottom: 0;
        }

        .slider-track {
          display: flex;
          gap: 20px;
          width: max-content;
          will-change: transform;
        }

        .slider-row-left .slider-track {
          animation: scrollLeft 35s linear infinite;
        }

        .slider-row-right .slider-track {
          animation: scrollRight 35s linear infinite;
        }

        .slider-row:hover .slider-track {
          animation-play-state: paused;
        }

        /* Card Container */
        .slider-card {
          position: relative;
          width: 320px;
          height: 220px;
          flex-shrink: 0;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 8px 20px rgba(5, 52, 86, 0.08);
          cursor: pointer;
          transition: transform 0.35s ease, box-shadow 0.35s ease;
        }

        .slider-card:hover {
          transform: translateY(-5px);
          box-shadow: 0 16px 32px rgba(5, 52, 86, 0.18);
        }

        /* Contrast Overlay */
        .card-overlay {
          position: absolute;
          inset: 0;
          background: linear-gradient(
            rgba(0, 0, 0, 0.05) 0%,
            rgba(0, 0, 0, 0.25) 40%,
            rgba(0, 0, 0, 0.65) 100%
          );
          transition: background 0.3s ease;
          z-index: 1;
        }

        .slider-card:hover .card-overlay {
          background: linear-gradient(
            to top,
            rgba(0, 0, 0, 0.95) 0%,
            rgba(0, 0, 0, 0.5) 60%,
            rgba(0, 0, 0, 0.15) 100%
          );
        }

        /* Text Content */
        .card-content {
          position: absolute;
          left: 0;
          right: 0;
          bottom: 0;
          padding: 20px;
          z-index: 2;
        }

        .title-h3 {
          color: #ffffff;
          font-size: 20px;
          font-weight: 600;
          line-height: 1.3;
          margin: 0;
          text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        /* Keyframe Animations */
        @keyframes scrollLeft {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }

        @keyframes scrollRight {
          0% {
            transform: translateX(-50%);
          }
          100% {
            transform: translateX(0);
          }
        }

        /* Responsive Breakpoints */
        @media (max-width: 768px) {
          .slider-card {
            width: 250px;
            height: 180px;
            border-radius: 12px;
          }

          .title-h3 {
            font-size: 16px;
          }

          .card-content {
            padding: 14px;
          }
        }
      `}</style>
    </section>
  );
};

export default DualDirectionSlider;