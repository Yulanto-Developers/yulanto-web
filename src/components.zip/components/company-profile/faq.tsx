"use client";

import React, { useState } from "react";
import { motion, Variants, HTMLMotionProps } from "framer-motion";

// ==========================================
// 1. TYPES & INTERFACES
// ==========================================

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}

export interface FaqRow {
  id: string;
  speed?: string;
  direction?: "left" | "right";
  faqItems: FaqItem[];
}

export interface FaqSectionData {
  mainTitleBlue?: React.ReactNode;
  mainTitleBlack?: React.ReactNode;
  mainDescription?: React.ReactNode;
  rows: FaqRow[];
}

export interface FaqSectionProps
  extends Omit<HTMLMotionProps<"section">, "ref"> {
  data?: FaqSectionData;
}

// ==========================================
// 2. DEFAULT FALLBACK FAQ DATA
// ==========================================

export const defaultFaqData: FaqSectionData = {
  mainTitleBlue: "Frequently Asked ",
  mainTitleBlack: "Questions",
  mainDescription:
    "Everything you need to know about our services and process.",
  rows: [
    {
      id: "row1",
      speed: "55s",
      direction: "left",
      faqItems: [
        {
          id: "q1",
          question: "What graphic design services do you provide?",
          answer:
            "We provide brochure design, company profile design, catalogue design, presentation design, poster design, and other marketing materials.",
        },
        {
          id: "q2",
          question: "Why should I hire a professional design agency?",
          answer:
            "A professional agency ensures brand consistency, strategic layout hierarchy, and polished visual appeal that elevates your brand presence.",
        },
      ],
    },
    {
      id: "row2",
      speed: "65s",
      direction: "right",
      faqItems: [
        {
          id: "q3",
          question: "Can I request revisions during the design process?",
          answer:
            "Yes. We incorporate client feedback into the design iteration cycles to deliver results aligned with your expectations.",
        },
        {
          id: "q4",
          question: "What file formats do you deliver?",
          answer:
            "We provide print-ready PDFs, high-resolution vector files, and web-optimized graphic formats.",
        },
      ],
    },
  ],
};

// ==========================================
// 3. SUB-COMPONENTS
// ==========================================

export const FaqCard: React.FC<FaqItem> = ({ question, answer }) => {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        gap: "12px",
        padding: "24px",
        backgroundColor: "#ffffff",
        borderRadius: "16px",
        border: "1px solid #eaeaea",
        width: "380px",
        flexShrink: 0,
        cursor: "pointer",
        boxShadow: "0 4px 12px rgba(0, 0, 0, 0.03)",
      }}
    >
      <h3
        className="text-blue-about"
        style={{
          fontSize: "18px",
          fontWeight: 700,
          fontFamily: "Figtree, Figtree Fallback",
          lineHeight: "1.4",
          margin: 0,
        }}
      >
        {question}
      </h3>
      <p
        className="text-figtree"
        style={{
          fontSize: "15px !important",
          color: "#555555",
          lineHeight: "1.6",
          margin: 0,
        }}
      >
        {answer}
      </p>
    </div>
  );
};

export const HorizontalScroller: React.FC<{
  children: React.ReactNode;
  speed?: string;
  direction?: "left" | "right";
}> = ({ children, speed = "40s", direction = "left" }) => {
  const [isHovered, setIsHovered] = useState(false);

  const animationName =
    direction === "right" ? "scrollHorizontalReverse" : "scrollHorizontal";

  return (
    <div
      style={{
        width: "100%",
        overflow: "hidden",
        position: "relative",
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div
        style={{
          display: "flex",
          width: "max-content",
          animation: `${animationName} ${speed} linear infinite`,
          animationPlayState: isHovered ? "paused" : "running",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "stretch",
            gap: "24px",
            paddingLeft: "12px",
            paddingRight: "12px",
            flexShrink: 0,
          }}
        >
          {children}
        </div>
        {/* Duplicate content for infinite scrolling loop */}
        <div
          style={{
            display: "flex",
            alignItems: "stretch",
            gap: "24px",
            paddingLeft: "12px",
            paddingRight: "12px",
            flexShrink: 0,
          }}
          aria-hidden="true"
        >
          {children}
        </div>
      </div>
    </div>
  );
};

// ==========================================
// 4. REUSABLE MAIN FAQ SECTION
// ==========================================

export const FaqSection = React.forwardRef<HTMLElement, FaqSectionProps>(
  ({ className, data = defaultFaqData, ...props }, ref) => {
    const containerVariants: Variants = {
      hidden: { opacity: 0 },
      visible: {
        opacity: 1,
        transition: {
          staggerChildren: 0.15,
          delayChildren: 0.2,
        },
      },
    };

    const itemVariants: Variants = {
      hidden: { y: 20, opacity: 0 },
      visible: {
        y: 0,
        opacity: 1,
        transition: {
          duration: 0.5,
          ease: "easeInOut",
        },
      },
    };

    return (
      <motion.section
        ref={ref}
        className={`px-about-6-area pt-50 pb-80 pb-lg-110 ${className || ""}`}
        style={{ overflow: "hidden", backgroundColor: "#fff" }}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
        variants={containerVariants}
        {...props}
      >
        <style>{`
          @keyframes scrollHorizontal {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
          }
          @keyframes scrollHorizontalReverse {
            0% { transform: translateX(-50%); }
            100% { transform: translateX(0); }
          }
        `}</style>

        <div className="container container-1550">
          {/* Header Section */}
          <div className="row align-items-center mb-50">
            <div className="col-xl-12">
              <motion.div
                className="px-project-title-box text-center"
                variants={containerVariants}
              >
                <motion.h4
                  className="px-about-title mb-20 text-center"
                  variants={itemVariants}
                >
                  {data.mainTitleBlue && (
                    <span className="text-blue-about">
                      {data.mainTitleBlue}
                    </span>
                  )}
                  {data.mainTitleBlack && (
                    <span style={{ color: "#000000" }}>
                      {data.mainTitleBlack}
                    </span>
                  )}
                </motion.h4>
                {data.mainDescription && (
                  <motion.p
                    className="text-figtree text-black mt-2"
                    variants={itemVariants}
                  >
                    {data.mainDescription}
                  </motion.p>
                )}
              </motion.div>
            </div>
          </div>

          {/* Scrolling Rows */}
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "24px",
              marginTop: "30px",
              width: "100%",
            }}
          >
            {data.rows.map((row) => (
              <HorizontalScroller
                key={row.id}
                speed={row.speed}
                direction={row.direction}
              >
                {row.faqItems.map((item) => (
                  <FaqCard
                    key={item.id}
                    id={item.id}
                    question={item.question}
                    answer={item.answer}
                  />
                ))}
              </HorizontalScroller>
            ))}
          </div>
        </div>
      </motion.section>
    );
  }
);

FaqSection.displayName = "FaqSection";

export default FaqSection;