import DigitalStudioServiceItem from "../components/DigitalStudioServiceItem";
import { servicesData } from "@/data/services-data";

const DigitalStudioService = () => {
    //service item
    const serviceItems = servicesData.slice(8, 12);

    return (
        <div
            className="bf-service-area bf-service-3-rounded pt-30 pb-160"
            style={{ backgroundColor: "#053456" }}
        >
            <div className="container container-1320">
                <div
                    className="bf-service-heading mb-10 tp_fade_anim"
                    data-delay=".3"
                >
                    <span className="tp-section-subtitle text-white blink-ball">
                        We Offered
                    </span>
                </div>
                <div className="row">
                    {/* <div className="col-lg-5">

                    </div> */}
                    <div className="col-lg-12">
                        <div className="bf-service-heading mb-60">
                            <h3
                                className="bf-section-title-3 text-white mb-20 tp_fade_anim"
                                data-delay=".3"
                            >
                                Service we&apos;re
                                 always provides
                            </h3>
                            <div className="tp_text_anim">
                                <p className="bf-service-3-dec">
                                    Our dedicated team of web Designers in Chennai excels in web design, web development, e-commerce
                                    websites, logo
                                    design, custom development, SEO, and SMM, ensuring top-notch services.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                {serviceItems.map((service) => (
                    <DigitalStudioServiceItem {...service} key={service.id} />
                ))}
            </div>
        </div>
    );
};

export default DigitalStudioService;