"use client";

import AnimatedCounterTree from "@/components/shared/MetricsCounter/AnimatedCounterThree";
import { SmartLink } from "@/components/common";
import { TextArrowIcon } from "@/svg";
import Image from "next/image";
import "./majorclient.css";

/* =========================================================
   DATA
========================================================= */

export const majorCItems = [
    "Branding",
    "Digital Design",
    "Marketing Assets",
    "Development",
];

export const innerClient = [
    {
        id: 1,
        title: "Branding",

        descriptions: [
            "Strong branding sets your startup apart, signaling quality and professionalism. It builds trust with your audience, making you stand out in a crowded market.",
        ],

        categories: [
            "Brand Naming",
            "Creative Direction",
            "Brand Strategy",
            "Graphic charter",
            "Logo Design",
        ],

        images: [
            "/assets/img/service/inner-service/service-1.jpg",
            "/assets/img/service/inner-service/service-2.jpg",
        ],
    },

    {
        id: 2,
        title: "Digital Design",

        descriptions: [
            "A process of assumption & validation with a goal of taking into account all the necessary variables, which are always custom and are to be uncovered.",

            "Every business has digital potential, and we are here to help you leverage that potential.",
        ],

        categories: [
            "Wireframe",
            "UI design",
            "Prototyping",
            "Design system",
            "UI & UX audit",
            "Design System",
            "Interactive Experiences",
        ],

        images: [
            "/assets/img/service/inner-service/service-3.jpg",
            "/assets/img/service/inner-service/service-4.jpg",
        ],
    },

    {
        id: 3,
        title: "Marketing Assets",

        descriptions: [
            "Marketing strategy is proudly responsible for the half of a campaign's success, another half relies solely on its implementation.",

            "We focus on creating visuals that communicate your value and engage your audience.",
        ],

        categories: [
            "Animated logos",
            "Product Illustrations",
            "Launch Videos",
            "Illustrations",
            "Visual Effects",
            "Illustration 3D",
        ],

        images: [
            "/assets/img/service/inner-service/service-5.jpg",
            "/assets/img/service/inner-service/service-6.jpg",
        ],
    },

    {
        id: 4,
        title: "Development",

        descriptions: [
            "Efficiency and scalability. The two factors which any decision gets filtered out with - programming language, framework, library, each line of code, and server side.",
        ],

        categories: [
            "Integration",
            "Front-end",
            "Back-end",
            "Webflow",
        ],

        images: [
            "/assets/img/service/inner-service/service-7.jpg",
            "/assets/img/service/inner-service/service-8.jpg",
        ],
    },
];

/* =========================================================
   TYPES
========================================================= */

interface InnerServiceItemProps {
    id: number;
    title: string;
    descriptions: string[];
    categories: string[];
    images: string[];
    isLastItem?: boolean;
}

/* =========================================================
   RIGHT SIDE ITEM
========================================================= */

const MajorInnerItems = ({
    id,
    title,
    descriptions,
    categories,
    images,
    isLastItem = false,
}: InnerServiceItemProps) => {
    return (
        <div
            id={`major-service-${id}`}
            className={`major-inner-service-item ${
                !isLastItem ? "major-inner-service-spacing" : ""
            }`}
        >
            {/* =========================================
                NUMBER + CONTENT
            ========================================= */}
            <div className="major-inner-service-right">
                <div className="row">
                    {/* NUMBER */}
                    <div className="col-xl-4 col-lg-3">
                        <div className="major-inner-service-number">
                            <h1>
                                <AnimatedCounterTree
                                    end={id}
                                    duration={0.2}
                                />
                            </h1>
                        </div>
                    </div>

                    {/* TEXT + CATEGORIES */}
                    <div className="col-xl-8 col-lg-9">
                        <div className="major-inner-service-text">
                            <span>{title}</span>

                            {descriptions.map((description, index) => (
                                <p key={`description-${id}-${index}`}>
                                    {description}
                                </p>
                            ))}
                        </div>

                        {/* CATEGORIES */}
                        <div className="major-inner-service-category">
                            {categories.map((category, index) => (
                                <SmartLink
                                    key={`${category}-${index}`}
                                    href="/service-2"
                                    className="major-inner-service-category-item d-flex justify-content-between align-items-center"
                                >
                                    <span>{category}</span>

                                    <i>
                                        <TextArrowIcon />
                                    </i>
                                </SmartLink>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            {/* =========================================
                IMAGES
            ========================================= */}
            <div className="row gx-10 major-inner-service-images-row">
                <div className="major-inner-service-thumb-text">
                    <span>(Our recent Digital work)</span>
                </div>

                {images.map((image, index) => (
                    <div
                        key={`${image}-${index}`}
                        className="col-xl-6 col-lg-6"
                    >
                        <div className="major-inner-service-thumb">
                            <div className="major-inner-service-ripple-image">
                                <Image
                                    className="w-100 img-fluid"
                                    width={643}
                                    height={720}
                                    src={image}
                                    alt={`${title} ${index + 1}`}
                                />
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

/* =========================================================
   MAIN COMPONENT
========================================================= */

const MajorClientService = () => {
    return (
        <section className="major-client-service-area">
            <div className="container container-1830">
                <div className="row major-client-service-row">

                    {/* =====================================
                        LEFT SIDE
                        STICKY
                    ===================================== */}
                    <div className="col-lg-3 major-client-left-column">
                        <div className="major-client-left">
                            <span className="major-client-left-title">
                                Services
                            </span>

                            <ul className="major-client-service-nav">
                                {majorCItems.map((item, index) => (
                                    <li key={item}>
                                        <a
                                            href={`#major-service-${
                                                index + 1
                                            }`}
                                        >
                                            <span>
                                                {String(index + 1).padStart(
                                                    2,
                                                    "0"
                                                )}
                                                .
                                            </span>

                                            <span>{item}</span>
                                        </a>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>

                    {/* =====================================
                        RIGHT SIDE
                        NORMAL PAGE SCROLL
                    ===================================== */}
                    <div className="col-lg-9 major-client-right-column">
                        {innerClient.map((service, index) => (
                            <MajorInnerItems
                                key={service.id}
                                id={service.id}
                                title={service.title}
                                descriptions={service.descriptions}
                                categories={service.categories}
                                images={service.images}
                                isLastItem={
                                    index === innerClient.length - 1
                                }
                            />
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default MajorClientService;