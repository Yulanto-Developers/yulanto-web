"use client";

import CardSwap, { Card } from "./CardSwap";

import Image1 from "@/assets/img/sample/gallery/img- (1).jpg";

export default function RecentProject() {
    const cardObj = [
        {
            title: "Naturographers",
            subTitle: "Tour Booking",
            image: Image1,
        },
        {
            title: "Naturographers",
            subTitle: "Tour Booking",
            image: Image1,
        },
        {
            title: "Naturographers",
            subTitle: "Tour Booking",
            image: Image1,
        },
    ];

    return (
        <section className="py-5">
            <div className="container row">
                <div className="col-12">
                    <p>Discover our most recent accomplishments, a demonstration of our steadfast
                        commitment to originality and advancement. From state-of-the-art websites that
                        flawlessly integrate style and functionality to captivating logos that
                        encapsulate the core of your brand, every undertaking showcases our
                        determination to surpassing anticipations.</p>
                </div>

            </div>
            <div
                className="container"
                style={{
                    height: "600px",
                    position: "relative",
                }}
            >
                <CardSwap
                    width={800}
                    height={400}
                    cardDistance={60}
                    verticalDistance={70}
                    delay={5000}
                    pauseOnHover={true}
                >
                    {cardObj.map(
                        (item, index) => (
                            <Card
                                key={index}
                                style={{
                                    backgroundImage: `url("${item.image.src}")`,
                                    backgroundSize:
                                        "cover",
                                    backgroundPosition:
                                        "center",
                                    backgroundRepeat:
                                        "no-repeat",
                                }}
                            >
                                <div className="card-swap-content">
                                    <h3>
                                        {item.title}
                                    </h3>

                                    <p>
                                        {item.subTitle}
                                    </p>
                                </div>
                            </Card>
                        )
                    )}
                </CardSwap>
            </div>
        </section>
    );
}